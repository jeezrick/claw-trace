# Trace Service

把 OpenClaw session 链路网页做成可访问服务。

## 目录

- `public/` 前端页面（index.html / styles.css / app.js）
- `server.js` 轻量 HTTP 服务 + API

## 一键安装（给其他服务器用）

先在你的这台机器上运行一次，生成下载包：

```bash
cd /root/.openclaw/workspace/trace-service
bash build-bundle.sh
```

然后让对方在他们服务器上执行一条命令（把 `<你的机器IP>` 改成你机器可访问的 IP）：

```bash
curl -fsSL http://<你的机器IP>:8787/trace-service.tgz | tar -xz && cd trace-service && chmod +x run.sh && nohup ./run.sh >/tmp/trace-service.log 2>&1 &
```

启动后访问：`http://<对方机器IP>:8787`

## 本机启动

```bash
cd /root/.openclaw/workspace/trace-service
node server.js
```

默认监听：`0.0.0.0:8787`

## 环境变量

- `PORT`：端口（默认 `8787`）
- `HOST`：监听地址（默认 `0.0.0.0`）
- `SESSIONS_DIR`：session 数据目录（默认 `/root/.openclaw/agents/main/sessions`）

示例：

```bash
HOST=0.0.0.0 PORT=8787 SESSIONS_DIR=/root/.openclaw/agents/main/sessions node server.js
```

## API

- `GET /api/sessions` -> 读取 `sessions.json`
- `GET /api/session-file?file=<session.jsonl>` -> 读取指定 `jsonl`

> 安全限制：仅允许读取 `sessions.json` 和形如 `xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx.jsonl` 的文件名。
